import java.sql.SQLOutput;

public class Main {
    public static void main(String[] args) {
        //condicional
        int numeroIf = 1;
        if (numeroIf>0){
            System.out.println("es positivo");
        } else {
            System.out.println("es negativo");
        }

        //bucle while
        int numeroWhile=1;
        while(numeroWhile<3){
            System.out.println(numeroWhile);
            numeroWhile++;
        }

        //bucle do while
        do {
            System.out.println(numeroWhile);
            numeroWhile++;
        }
        while(numeroWhile==3);

        //bucle for
        for(int numeroFor=0; numeroFor<=3; numeroFor++){
            System.out.println(numeroFor);
        }

        //switch case
        String estacion="VERANO";
        switch (estacion){
            case "VERANO":
                System.out.println(estacion);
                break;
            case "OTOÑO":
                System.out.println(estacion);
                break;
            case "INVIERNO":
                System.out.println(estacion);
                break;
            case "PRIMAVERA":
                System.out.println(estacion);
                break;
            default:
                System.out.println("No es una estación del año");
                break;
        }
    }
}