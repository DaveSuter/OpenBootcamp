public class Coche {
    public int cantidadPuertas;

    public void incrementarPuertas(){
        cantidadPuertas++;
    }
}
