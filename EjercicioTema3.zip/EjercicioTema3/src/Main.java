public class Main {
    public static void main(String[] args) {
        //Llamado a la funcion con valores
        sumarNumeros(1,2,3);

        Coche miCoche = new Coche();
        miCoche.incrementarPuertas();
        System.out.println(miCoche.cantidadPuertas);
    }

    public static int sumarNumeros(int a, int b, int c){
        return a+b+c;
    }


}